/**
 * Decrypt a file
 * @param encryptedFile
 * @param privateKey path to pem formatted key
 * @param symKey base64 encoded
 * @param iv base64 encoded
 * @param output decrypted file destination
 */
const fs = require("fs");

if(!process.argv || process.argv.length !== 7){
  console.log(
`Invalid params. Usage:
    ${__filename.replace(`${__dirname}/`, '')} encrypted_source_path private_key_path SYM_KEY_enc_b64 IV_base64 output_file_name
`);
    process.exit(1);
}

// Validating parameters
const data = {
  source: process.argv[2],
  privKey: process.argv[3],
  symKey: Buffer.from(process.argv[4], 'base64'),
  iv: Buffer.from(process.argv[5], 'base64'),
  destination: process.argv[6],
};

if(!fs.existsSync(data.source)){
  console.log(`File for decryption not found: ${data.source}.\nExiting...`);
  process.exit(1);
};

if(!fs.existsSync(data.privKey)){
  console.log(`Private key not found: ${data.privKey}.\nExiting...`);
  process.exit(1);
};

if(!data.symKey){
  console.log(`Missing SYM_KEY for decryption.\n Exiting...`);
  process.exit(1);
}

if(!data.iv){
  console.log(`Missing IV for decryption.\n Exiting...`);
  process.exit(1);
}

const cryptoManager = require('genkidama').CryptoManager;
const cryptoHandler = cryptoManager.Aes256CtrOAEP();

// Decrypting
try{
  const privKey = fs.readFileSync(data.privKey).toString();
  const decSymKey = cryptoHandler.decryptAsym(privKey, data.symKey);
  const decrypted = cryptoHandler.decryptSym(decSymKey, Buffer.from(data.iv, 'base64'), data.source);
  const writeFile = fs.createWriteStream(data.destination);

  decrypted.pipe(writeFile);

}catch(error){
  console.error(`
  Could not decrypt file.
  Cause  - ${error}
  `);
  process.exit(1);
}